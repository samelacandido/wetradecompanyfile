<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <img src="assets/img/logov6.png" alt="Logo" width="32" height="32" style="border-radius: 50%;">&nbsp;
        <a class="navbar-brand" href="#">WeTrade Company</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo02" style="z-index:10;">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="aboutUs.php">About Us</a>
                </li>
            </ul>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Login
            </button>
        </div>
    </div>
</nav>
<div>
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        
			<div class="modal-content">
			
			<form method="POST" action="loginSubmit.php">
				<div class="modal-header">
					<h3>Login To Continue</h3>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<div class="mb-3">
						<label for="exampleFormControlInput1" class="form-label">Email</label>
						<input name="user" type="text" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
					</div>
					<div class="mb-3">
						<label for="exampleFormControlInput1" class="form-label">Password</label>
						<input name="pass" type="password" class="form-control" id="exampleFormControlInput1" placeholder="">
					</div>
					<a data-bs-target="#forgetPassModal" data-bs-toggle="modal" href="#">Forget Password?</a><br>
					<p>Don't have an account yet? <a data-bs-target="#registerModal" data-bs-toggle="modal" href="" >Click Here!</a></p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					<button name="submit" type="submit" class="btn btn-primary">Login</button>
				</div>
			</form>
			</div>
		
    </div>
</div>
<div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog " style="overflow-y:auto;">
        <div class="modal-content">
            <div class="modal-header">
				<h3>Account Registration</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
			<form method="POST" action="registration.php" >
            <div class="modal-body container">
                
                    <div class="mb-3">
                        <label for="regGName" class="form-label">Given Name</label>
                        <input name="fname" type="text" class="form-control" id="fname" placeholder="Juan" required>
                    </div>
                    <div class="mb-3">
                        <label for="regMName" class="form-label">Middle Name</label>
                        <input name="mname" type="text" class="form-control" id="mname" placeholder="Santos">
                    </div>
                    <div class="mb-3">
                        <label for="regLName" class="form-label">Last Name</label>
                        <input name="lname" type="text" class="form-control" id="lname" placeholder="Dela Cruz" required>
                    </div>
                    <div class="mb-3">
                        <label for="regEMail" class="form-label">Email Address</label>
                        <input name="email"type="text" class="form-control" id="email" placeholder="juandelacruz@domain.com" required>
                    </div>
                    <div class="mb-3">
                        <label for="regPassword" class="form-label">Password</label>
                        <input name="pass" type="password" class="form-control" id="pass" required>
                    </div>
                    <div class="mb-3">
                        <label for="regPassword2" class="form-label">Confirm Password</label>
                        <input name="pass2" type="password" class="form-control" id="pass2" required>
                    </div>
                    <div class="mb-3">
                        <label for="regUserName" class="form-label">Username</label>
                        <input name="username" type="text" class="form-control" id="username" placeholder="juandelacruz123" required>
                    </div>
                    <div class="mb-3">
                        <label for="regBDate" class="form-label">Birthdate</label>
                        <input name="bdate" type="date" class="form-control" id="bdate" required>
                    </div>
                    <div class="mb-3">
                        <label for="gender" class="form-label">Gender</label>
                        <select name="gender" class="form-select" id="gender" required>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Others</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="regCNumber" class="form-label">Contact Number</label>
                        <input name="cpnumber" type="tel" class="form-control" id="cpnumber" required>
                    </div>
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button name="submit" type="submit" class="btn btn-primary">Register</button>
            </div>
			</form>
        </div>
    </div>
</div>
</div>
<div>
<div class="modal fade" id="forgetPassModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        
			<div class="modal-content">
			
			<form method="POST" action="forgetPassword.php">
				<div class="modal-header">
					<h3>Forget Password</h3>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<div class="mb-3">
						<label for="exampleFormControlInput1" class="form-label">Registered Email</label>
						<input name="email" type="text" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					<button name="password-reset-token" type="submit" class="btn btn-primary">Submit</button>
				</div>
			</form>
			</div>
		
    </div>
</div>
