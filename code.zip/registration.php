<?php
session_start(); 

$fname=$_POST['fname'];  
$mname=$_POST['mname']; 
$lname=$_POST['lname']; 
$email=$_POST['email']; 
$pass=$_POST['pass']; 
$pass2=$_POST['pass2'];
$username=$_POST['username']; 
$bdate=$_POST['bdate']; 
$gender=$_POST['gender']; 	
$notfoundemail = 0;
$notfounduser = 0;
$pass_hash = password_hash($_POST['pass'],PASSWORD_DEFAULT);

do{
	if(isset($_POST["submit"]))
	{  
		if(!empty($_POST['fname']) && !empty($_POST['lname']) && !empty($_POST['email']) && !empty($_POST['pass']) && !empty($_POST['username']) && !empty($_POST['bdate']) && !empty($_POST['gender']) && !empty($_POST['pass2'])) 
			{
			if($pass != $pass2)
			{
				echo '<script>alert("please confirm your password!")</script>';
				//header("Location: ./loginPage.php");
				break;
			}
			else{
			    include "db.php";
		  
    			$check_email_query=mysqli_query($con,"SELECT * FROM account_info WHERE email_add='".$email."'");  
    			$numrows_email=mysqli_num_rows($check_email_query);
    			if($numrows_email!=0)  
    			{
    				while($row=mysqli_fetch_assoc($check_email_query))  
    				{  
    					$dbemail=$row['email_add'];  
    				}  
    				if($email == $dbemail)  
    				{  
    					echo '<script>alert("email already registered, please login!")</script>';
    					//header("Location: ./loginPage.php"); 
    					break;
    				}
    			}
    			else{
    				$notfoundemail = 1;
    				//echo '<script>alert("no rows in email found!")</script>';
    				//header("Location: ./loginPage.php");
    				break;
    			}
    			
    			$check_user_query=mysqli_query($con,"SELECT * FROM account_info WHERE username='".$username."'");  
    			$numrows_user=mysqli_num_rows($check_user_query);
    			if($numrows_user!=0)  
    			{ 
    				while($row=mysqli_fetch_assoc($check_user_query))  
    				{  
    					$dbusername=$row['username'];  
    				}  
    				if($username == $dbusername)  
    				{ 
    					echo '<script>alert("username already registered, please login!")</script>';
    					//header("Location: ./loginPage.php");
    					break;
    				}
    			}
    			else{
    				$notfounduser = 1;
    				//echo '<script>alert("no rows in username found!")</script>';
    				//header("Location: ./loginPage.php");
    				break;
    			}
			
		        mysqli_close($con);	
			}
		   
            
			
		
		}
		else 
		{    
			echo '<script>alert("All fields are required!")</script>';
			//header("Location: ./loginPage.php");
			break;
		}  

	}
	
}while(0);

if($notfounduser == 1 || $notfoundemail == 1)
{
	include "db.php";
  
	$sql = "INSERT INTO account_info (first_name,m_name,last_name,b_date,gender,email_add,password,username,password_hashed,role) VALUES ('$fname','$mname','$lname','$bdate','$gender','$email','$pass','$username','$pass_hash','client')";
	  
	$query=mysqli_query($con,$sql);  
		
	if($query)
	{
		$get_accntnum_query=mysqli_query($con,"SELECT * FROM account_info WHERE email_add='".$email."'");  
		$numrows_accntnum=mysqli_num_rows($get_accntnum_query);
		if($numrows_accntnum!=0)  
		{
			while($row=mysqli_fetch_assoc($get_accntnum_query))  
			{  
				$dbaccntnum=$row['account_number'];  
				$dbemail=$row['email_add'];  
			}  
			if($email == $dbemail)  
			{  
				$_SESSION['sess_user']=$username;  
				$_SESSION['sess_accountnumb']=$dbaccntnum;
				//echo "test : " . $_SESSION['sess_accountnumb'];
				//echo "test" . $_SESSION['sess_user'];
				$_SESSION['sess_fname']=$fname;
				$_SESSION['sess_lname']=$lname;
				header("Location: ./clientPage.php");  
			}
		}
	}
	mysqli_close($con);
}
?>
