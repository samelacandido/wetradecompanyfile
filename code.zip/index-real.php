<?php
include 'includes/headerView.php';
include 'homeNav.php';

include 'home.php';
include 'includes/footerView.php';
?>  


    