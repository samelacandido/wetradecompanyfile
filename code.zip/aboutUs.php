<?php
include 'includes/headerView.php';
include 'homeNav.php';
?>
<div class="container">
    <div id="about-section">
      <h1 class="textwhite">About Us</h1>
      <p>InTrade Business is a blockchain-based trading platform that digitalises your entire trading process. It seamlessly connects your trade ecosystem and making trades fast. One of our sources is Auction Gold where we bidd to our clients with the good value and best price of our item. Second is Forex Trading one of our support in multiplying amounts with the guide of We Trade Professional Trader in Meta Trader 4 platform.</p>
      
      
      <h1 class="textwhite">Mission</h1>
      <p>To be the leading provider of successful investing in trading platform by helping people to gain best profit to all aspects of money management and follow proven, objective investment strategies and become essential to our investor's  by making way to achieve their goals. </p>
      
      <h1 class="textwhite">Vision</h1>
      <p>We help individuals excel at providing for thier family and support legal opportunities by helping them excel as investors. To entertain, inform and inspire people around the investment industry through the power of unparalleled sources, reflecting the iconic items, creative minds, and innovative platform that make our's the pioneer entertainment company.</p>
      
    </div>
    <!--
    <h2 style="text-align:center">Our Team</h2>
    <div class="row">
      <div id="column">
        <div id="card">
          <img src="/w3images/team1.jpg" alt="Jane" style="width:100%">
          <div class="container">
            <h2>Jane Doe</h2>
            <p class="title">CEO & Founder</p>
            <p>Some text that describes me lorem ipsum ipsum lorem.</p>
            <p>jane@example.com</p>
            <p><button id="AUbutton">Contact</button></p>
          </div>
        </div>
      </div>
    
      <div id="column">
        <div id="card">
          <img src="assets/img/human.jpg" alt="Mike" style="width:100%; height:80%;">
          <div class="container">
            <h2>Mike Ross</h2>
            <p class="title">Art Director</p>
            <p>Some text that describes me lorem ipsum ipsum lorem.</p>
            <p>mike@example.com</p>
            <p><button id="AUbutton">Contact</button></p>
          </div>
        </div>
      </div>
      
      <div id="column">
        <div id="card">
          <img src="/w3images/team3.jpg" alt="John" style="width:100%">
          <div class="container">
            <h2>John Doe</h2>
            <p class="title">Designer</p>
            <p>Some text that describes me lorem ipsum ipsum lorem.</p>
            <p>john@example.com</p>
            <p><button id="AUbutton">Contact</button></p>
          </div>
        </div>
      </div>
    </div>
    -->
</div>
<?php
include 'includes/footerView.php';
?>