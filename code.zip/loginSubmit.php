<?php  
session_start(); 
if(isset($_POST["submit"]))
{  
	if(!empty($_POST['user']) && !empty($_POST['pass'])) 
	{  
		$user=$_POST['user'];  
		$pass=$_POST['pass'];  
	  
		$con=mysqli_connect('localhost','weTradeClientAdmin','sAdsvgr%24!') or die(mysql_error());  
		mysqli_select_db($con,'weTradeDb') or die("cannot select DB");  
	  
		$query=mysqli_query($con,"SELECT * FROM account_info WHERE email_add='".$user."' ");  
		$numrows=mysqli_num_rows($query);  
		if($numrows!=0)  
		{  
			while($row=mysqli_fetch_assoc($query))  
			{  
				$dbusername=$row['email_add'];  
				$dbpassword=$row['password'];  
				$accountid=$row['account_number'];
				$accountfname=$row['first_name'];
				$accountlname=$row['last_name'];
				$dbrole=$row['role'];
				$password_hash = $row['password_hashed'];
				//echo $password_hash;
			}  
		  
			if($user == $dbusername && password_verify($pass,$password_hash))  
			{  
			 
				$_SESSION['sess_user']=$user;  
				$_SESSION['sess_accountnumb']=$accountid;
				//echo "test : " . $_SESSION['sess_accountnumb'];
				//echo "test" . $_SESSION['sess_user'];
				$_SESSION['sess_fname']=$accountfname;
				$_SESSION['sess_lname']=$accountlname;
			  
				/* Redirect browser */  
				if($dbrole == 'client')
				{
					header("Location: ./clientPage.php");  
				//echo "login successfully";
				}
				if($dbrole == 'admin'){
					header("Location: ./adminPage_dashboard.php");  
				}
				
				
			}  
			else{
				echo "wrong pass";
			}
		} 
		else 
		{  
			echo "Account not registered , please register!";   
		}  
	  
	} 
	else 
	{  
		echo "All fields are required!";  
	}  
}  