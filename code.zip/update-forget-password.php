<?php
if(isset($_POST['password']) && $_POST['reset_link_token'] && $_POST['email'])
{
    include "db.php";
    $emailId = $_POST['email'];
    $token = $_POST['reset_link_token'];
    $pass= $_POST['password'];
    //$password = md5($_POST['password']);
    $query = mysqli_query($con,"SELECT * FROM account_info WHERE reset_link_token='".$token."' and email_add='".$emailId."'");
    $pass_hash = password_hash($_POST['password'],PASSWORD_DEFAULT);
    $row = mysqli_num_rows($query);
    if($row)
    {
        mysqli_query($con,"UPDATE account_info set  password='" . $pass . "',password_hashed='" . $pass_hash . "', reset_link_token='" . NULL . "' ,exp_date='" . NULL . "' WHERE email_add='" . $emailId . "'");
        echo '<p>Congratulations! Your password has been updated successfully.</p>';
        
        $link = "
        <html>
        <head>
        <title>HTML email</title>
        </head>
        <body>
        <p>Good day!</p>
        </br>
        <p>We notice that your password in weTradeCompany has been changed, if this was you, you san safely disregard this email.</p>
        </br>
        <p>If this wasnt you, please contact us immediately at support@wetrade-company.com</p>
        </br>
        <p>Thank you,</p>
        <p>We Trade Company Team</p>
        </body>
        </html>
        ";
        //$link = wordwrap($msg,70);
        $subject = "Your password has been changed!";
        
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: forgetpassword@weTrade-Company.com' . "\r\n";
        if(mail($emailId,$subject,$link,$headers))
        {
          echo "Check Your Email and Click on the link sent to your email";
        }
        else
        {
          echo "Mail Error";
        }
    }else
    {
        echo "<p>Something goes wrong. Please try again</p>";
    }
}
?>