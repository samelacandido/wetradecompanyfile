<?php  
session_start(); 
$account_num=$_SESSION['sess_accountnumb'];

if(isset($_POST["saveProfile"])){  
  
	if(!empty($_POST['saveProfile'])) {  
		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$lname = $_POST['lname'];
		$bday = $_POST['bdate'];
		$gender = $_POST['gender'];
		
				
		$con=mysqli_connect('localhost','root','') or die(mysql_error());
		mysqli_select_db($con,'user') or die("cannot select DB");  
  
		$sql = "UPDATE account_info SET first_name='$fname',m_name='$mname',last_name='$lname',b_date='$bday',gender='$gender'";
	  
		$query=mysqli_query($con,$sql);  
		
		if($query)
		{
			echo "<script>alert('Saved changes.');</script>";
			//echo "Apply for buy-in completed";
			header("location:profile.php");
			
		}
		else{
			echo "Failed. Duplicate investment number_format";
		}
	} else {  
		echo "All fields are required!";  
	}  
}else {  
		echo "no data";  
	} 
?> 