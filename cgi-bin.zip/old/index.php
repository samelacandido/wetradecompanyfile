<?php

session_start();

if (isset($_GET['page'])) {
    include 'views/includes/headerView.php';
    include 'views/clientPage.php';
    include 'views/includes/footerView.php';
} else {
    include 'views/includes/headerView.php';
    include 'views/loginPage.php';
    include 'views/includes/footerView.php';
}

?>