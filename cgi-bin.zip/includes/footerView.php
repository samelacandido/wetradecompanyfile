<script src="assets/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="assets/js/bootstrap.min.js"></script>
<footer class="site-footer" style="style="z-index:-1;">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-6">
            <h6>About</h6>
            <p class="text-justify">
                 InTrade Business is a blockchain-based trading platform that digitalises your entire trading process. It seamlessly connects your trade ecosystem and making trades fast. One of our sources is Auction Gold where we bidd to our clients with the good value and best price of our item. Second is Forex Trading one of our support in multiplying amounts with the guide of We Trade Professional Trader in Meta Trader 4 platform.</p>
          </div>

          <div class="col-xs-15 col-md-3 footer-right">
              <div class="col">
                  <h6>Contact Us</h6>
            	  <form action="#" method="post">

					<input class="contactUsText" style="width: 100%;" type="text" name="email" placeholder="Email">
					<textarea style="width: 100%;" name="message" placeholder="Message"></textarea>
					<button type="submit" class="btn btn-primary">Send</button>

				  </form>
              </div>
            </div>
        </div>
        <hr>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-10 col-xs-15">
            <p class="copyright-text">Copyright &copy; 2022 All Rights Reserved by 
         <a href="#">InTrade Business</a>.
            </p>
          </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
            <ul class="social-icons">  
            </ul>
            </div>
            <div class="col">
              <script id="godaddy-security-s" src="https://cdn.sucuri.net/badge/badge.js" data-s="2004" data-i="0346b47676a79108c2a6c35a27c47642aa0fc2cbd2" data-p="o" data-c="l" data-t="g">
              </script>
            </div>
        </div>
      </div>
</footer>
</body>

</html>