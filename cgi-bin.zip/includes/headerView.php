<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>WeTrade Company</title>

    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
	<link href="assets/css/sb-admin-2.min.css" rel="stylesheet">
	
	<link href="assets/css/testcss.css" rel="stylesheet">
	<link href="assets/css/footercss.css" rel="stylesheet">
	<link href="assets/css/profileCss.css" rel="stylesheet">
	
	<!-- for dropdown style ng profile but di nagana -->
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
		
	<link rel="stylesheet" href="assets/css/bitcoinstyle.css">
	<link rel="stylesheet" href="https://ds.fusioncharts.com/2.0.8/css/ds.css">
	<script src="https://ds.fusioncharts.com/2.0.8/js/ds.js"></script>
	<script type="text/javascript" src="http://cdn.fusioncharts.com/fusioncharts/latest/fusioncharts.js"></script>
	<script type="text/javascript" src="https://cdn.fusioncharts.com/fusioncharts/latest/themes/fusioncharts.theme.fusion.js"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<!--for allowing the edit in the profile-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</head>
<style>
<!--dropdown style-->
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.modal {
  overflow-y:auto;
}

table {
  border: 1px solid black;
  border-collapse: collapse;
  height: 200px;
  width: 80%;
}
 th, td {
  border: 1px solid white;
  font-size: 13px;
}
tr{
    line-height: 11px;
}


tbody {
	
}
.showbtn{
	color: #FFFFFF;
	text-decoration: none;
}
.showbtn:hover{
	color: #FFFFFF;
	text-decoration: underline;
}
h2{
	color: #FFFFFF;
}
body{
	background-color: black;
	
}
tr:hover {
	background-color: gray;
}
.textwhite{
	
	color: #FFFFFF;
}
.box{
	width: 80%;
	margin-left: 10%;
	margin-right: 10%;
}
.floatleft{
	
}
/*
img {
  border-radius: 50%;
}*/
/* search in admmin user page*/
#myInput {
  
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}
* {
  box-sizing: border-box;
}

/*about us design*/
#about-section {
    
  padding: 50px;
  text-align: center;
 
  background-image: url("assets/img/logoGradient20.png");
  background-repeat: no-repeat;
  background-position: center;
  color: white;
}
#card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

#column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}
#AUbutton {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}
</style>

<body >